# COMPLETE DOCUMENTATION ABOUT AARANA

## Development Environment

>OS WINDOWS 7 ULTIMATE
>PROCESSOR: INTEL(R) CORE(TM) DUO CPU E7300 @2.66 GHZ
>RAM: 4GB
>TOOlS
1.XAMPP v3.2.2
2.php v7.1.7
3.MariaDB v10.1.25 OR MySql > v5

/*** BACKEND DETAILS***/

/*** DATABASE NAME mlm2 ***/

>Table name - Product:
=====================
Main info stored in name column its value in content column.

+ Plane     - plane amount,
+ maxpin    - pins/request,
+ tl        - maximum left count,
+ tr        - maximum right count,
+ l1        - level one commision,
+ l2        - level two commision,
+ step      - number of steps to complete one stage
+ stage     - final step in the project 3(left side) + 3(right side) to complete 1 cycle