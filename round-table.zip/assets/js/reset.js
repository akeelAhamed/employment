'use strict';
let f = 0;
const form = function(form){
    let data = {};
    form.find('input').each(function(){
        data[$(this).attr('name')] = $(this).val();
    })

    return data;
}

$(function(){
    $(document).on('submit', 'form', function(e){
        e.preventDefault();
        let $this = $(this);
        let inputs = form($this), obj={};
        obj['input'] = inputs;
        obj['endpoint'] = obj.input.api;
        APP.submit($this);
        APP.api(obj, function (data) {
            APP.resetSubmit();
            if(data.s){
                $this[0].reset();
                if(f === 0){
                    f++;
                    $('form').html(data.m);
                }else{
                    APP.alert('Password changed successfully', true);
                    setTimeout(() => {
                        location.href = data.m;
                    }, 5000);
                }
            }else{
                APP.alert(data.m.join('<br/>'));
            }
        });
    })
})