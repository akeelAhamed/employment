<?php

namespace App\Middleware;

use App\Controllers\Auth\Auth AS Authenicate;

/**
 * Auth middleware to confirm the requeste is Auth
 */
class NoAuth{
    
    public function after($obj, $action)
    {
        if(!Authenicate::isLoggedIn()){
            return call_user_func(array($obj, $action));
        }

        return redirect('dashboard');
    }
}