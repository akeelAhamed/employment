<?php

namespace App\Controllers\Ajax;

use App\Models\Transaction;

class FilterController
{

    /**
     * Request variable
     */
    private static $request;

    /**
     * Request inputs
     */
    private static $inputs;

    /**
     * Column name to retrive
     */
    private static $column;

    /**
     * Is user an admin
     */
    private static $isAdmin;

    /**
     * Has relation in table
     */
    private static $relation = '';

    /**
     * Response variable
     */
    private static $response = ['s'=> false, 'm'=> 'No records found', 'th' => [] ];

    private static $alloedFilters = ['entry' => 'Transaction'];

    /**
     * Ajax index
     * 
     */
    public static function index()
    {
        self::$request = request();
        self::$inputs = self::$request->input('request');

        if(self::$inputs != null){
            if(self::$request->hasInput('request.input') && self::$request->hasInput('request.endpoint')){
                self::$inputs  = self::$request->input('request.input');
                $method = 'get'.\ucwords(self::$request->input('request.endpoint'));
                if(method_exists(get_called_class(), $method)){
                    self::$method(); // Call  method
                }
            }
        }
        return json_encode(self::$response);
    }

    /**
     * Get column name to return
     * 
     * @param string $mask Masked column name
     */
    public static function getSelectColumn($mask)
    {
        switch ($mask) {
            case 'entry':
                # User...
                self::$column = ['account', 'amount', 'ledger', 'sub_ledger','status', 'id', 'created_hj', 'created_at'];
                self::$relation = ['getAccount' => ['id', 'name'], 'getLedger'  => ['id', 'name']];
                break;
            
            default:
                # None...
                self::$column = '*';
                break;
        }

        return self::$column;
    }

    /**
     * Get actual column name
     * 
     * @param string $mask Masked column name
     */
    public static function getColumn($mask)
    {
        switch ($mask) {
            case 'u':
                # User...
                $column = 'user';
                break;

            case 'sl':
                # Sub ledger...
                $column = 'sub_ledger';
                break;

            case 'a':
                # Account...
                $column = 'account';
                break;
            
            default:
                # None...
                $column = '';
                break;
        }
        return $column;
    }

    /**
     * Get url based on user type
     */
    private static function _url($url, $nocheck=false)
    {
        return (self::$isAdmin || $nocheck)?url($url, true):'javascript:void(0)';
    }

    /**
     * Going to start filter
     * 
     * @param string $filter    Filter type
     * @param string $condition Filter condition
     * 
     * @return response
     */
    public static function start($filter, $condition)
    {
        $condition = explode('|', $condition);
        $column = self::getColumn($condition[0]);

        self::$isAdmin = \App\Controllers\Auth\Auth::isAdmin();

        if (isset(self::$alloedFilters[$filter]) && count($condition) > 1 && !empty($column) ) {
            self::getSelectColumn($filter);
            return self::$filter(self::$alloedFilters[$filter], $column, $condition[1]);
        }
        return self::$response;
    }

    /**
     * Get Ledger entry filter
     * 
     * @param string $m Modal
     * @param string $c Column
     * @param string $v Value
     * 
     * @return Filter rows
     */
    public static function entry($m, $c, $v)
    {
        $m = "\\App\\Models\\".$m;
        $m = new $m();
        if(self::$relation != ''){
            $m->with(self::$relation);
        }
        $rows = $m->where($v, $c)->orderBy('created_at', 'DESC')->get(self::$column);
        self::$response['m'] = [];
        self::$response['th'] = ['S.NO', 'ACCOUNT',	'AMOUNT', 'LEDGER',	'SUB LEDGER', 'STATUS', 'ENTRY DATE', 'ACTUAL DATE','VIEW'];
        $i = 1;

        foreach ($rows as $key => $row) {
            $status = ($row->status == 1)?'Verified' : 'Not verified';
            array_push(
                self::$response['m'],
                [
                    $i++,
                    '<a href="'. self::_url('account/edit/'. $row->getAccount[0]->id) . '" class="uk-button uk-button-link" target="_blank">'. $row->getAccount[0]->name . '</a>',
                    $row->amount,
                    $row->ledger,
                    '<a href="'. self::_url('ledger/edit/'. $row->getLedger[0]->id) . '" class="uk-button uk-button-link" target="_blank">'. $row->getLedger[0]->name . '</a>',
                    $status,
                    $row->created_hj,
                    $row->created_at,
                    '<a href="'. self::_url('entry/edit/' . $row->id, true) . '" class="uk-button uk-button-link" target="_blank">View</a>'
                ]
            );
        }
        self::$response['s'] = true;
        return self::$response;
    }

}