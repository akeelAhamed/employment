<?php

namespace App\Controllers\Ajax;

use App\Controllers\Account\AccountController;
use App\Libraries\Utill;
use App\Libraries\Validate;
use App\Models\User;
use App\Models\Ledger;
use App\Models\Transaction;

class PostController
{

    /**
     * Request variable
     */
    private static $request;

    /**
     * Request inputs
     */
    private static $inputs;

    /**
     * Response variable
     */
    private static $response = ['s'=> false, 'm'=> 'Request failed'];

    /**
     * Ajax index
     * 
     */
    public static function index()
    {
        self::$request = request();
        self::$inputs = self::$request->input('request');

        if(self::$inputs != null){
            if(self::$request->hasInput('request.input') && self::$request->hasInput('request.endpoint')){
                self::$inputs  = self::$request->input('request.input');
                $method = 'get'.\ucwords(self::$request->input('request.endpoint'));
                if(method_exists(get_called_class(), $method)){
                    self::$method(); // Call  method
                }
            }
        }
        return json_encode(self::$response);
    }

    /**
     * Get donation registration details associat with users
     */
    public static function getDonationx()
    {
        $sub = User::where(self::$request->input('request.input.user'))->get(['id', 'account', 'minimum', 'created_hj', 'created_g']);
        if($sub != null){
            $sub = [
                'sub' => explode(',', $sub[0]->account),
                'jon' => $sub[0]->created_hj,
                'jonG' => date('d-F-Y', strtotime($sub[0]->created_g)),
                'don' => $sub[0]->minimum,
                'led' => \App\Controllers\Account\CommonController::getPending($sub[0], true)
            ];
        }else{
            $sub = [];
        }
        self::$response['m'] = [
            'accounts' => AccountController::account(),
            'user' => $sub
        ];
        self::$response['s'] = true;
    }

    /**
     * Get sub ledger details associat with ledgers
     */
    public static function getslg()
    {
        $sub = Ledger::where(Ledger::DONID, 'id', '!=')->where(self::$request->input('request.input.ledger'), 'ledger')->get(['id', 'ledger', 'name']);
        if(count($sub) != 0){
            self::$response['m'] = $sub;
            self::$response['s'] = true;
        }else{
            $sub = [];
        }
    }

    /**
     * Get todays entry details
     */
    public static function getttx()
    {
        $sub = Transaction::with(['getAccount' => ['id', 'name'], 'getLedger'  => ['id', 'name']])->where(date('Y-m-d'), 'created_g')->orderBy('created_at', 'DESC')->get(['id', 'created', 'ledger', 'amount', 'account', 'status', 'sub_ledger']);
        
        if(count($sub) != 0){
            self::$response['me'] = \App\Controllers\Auth\Auth::user()->id;
            self::$response['m'] = $sub;
            self::$response['u'] = url('entry/edit/', true);
            self::$response['s'] = true;
        }else{
            $sub = [];
        }
    }

    /**
     * Filter from ajax
     */
    public static function getfilterX()
    {
        self::$response['th'] = ['S.NO', 'ACCOUNT',	'AMOUNT', 'LEDGER',	'SUB LEDGER', 'STATUS',	'VIEW'];
        $validate = Validate::validate(self::$inputs, 'fx');
        if($validate->status){
            self::$response = \App\Controllers\Ajax\FilterController::start(self::$inputs['f'], self::$inputs['k']);
        }else{
            self::$response['m'] = $validate->message;
        }
    }

    /**
     * Verify password reset code
     */
    public static function getrpv()
    {
        $validate = Validate::validate(self::$inputs, 'vot');
        if($validate->status){
            $code = self::$inputs['key'];
            $code = de($code, false);
            self::$response['s'] = ($code === self::$inputs['code']);
            if(self::$response['s']){
                self::$response['m'] = \App\Helpers\View::render('reset.password', self::$inputs, true);
            }else{
                self::$response['m'] = ['Invalid code'];
            }
        }else{
            self::$response['m'] = $validate->message;
        }
    }

    /**
     * Finaly reset password
     */
    public static function getrpw()
    {
        $validate = Validate::validate(self::$inputs, 'rpw');
        if($validate->status){
            $email = de(self::$inputs['id'], false);
            self::$response['m'] = ['Unable to reset password'];
            self::$response['s'] = User::where($email, 'email')->update(['password' => Utill::hashPassword(self::$inputs['confirm_password'])]);
            if(self::$response['s']){
                Utill::unsetSession();
                self::$response['m'] = url('', true);
            }
        }else{
            self::$response['m'] = $validate->message;
        }
    }

}