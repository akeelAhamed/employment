<?php

namespace App\Controllers;

use App\Helpers\View;

class ExceptionController
{
    /**
     * Base error folder
     */
    private static $eFolder = 'errors.';

    /**
     * 404 Error page 
     */
    public static function _404()
    {
        return View::render(self::$eFolder.'404');
    }

    /**
     * 405 Error page 
     */
    public static function _405()
    {
        return View::render(self::$eFolder.'405');
    }

    /**
     * 419 Unauthorized access
     */
    public static function _419()
    {
        return View::render(self::$eFolder.'419');
    }


}