<?php

namespace App\Controllers;

use App\Helpers\View;
use App\Controllers\Auth\Auth;
use App\Helpers\Mail;
use App\Libraries\Utill;

class HomeController
{
    /**
     * Show login form
     */
    public function index()
    {
        return View::render('welcome');
    }

    /**
     * Show register form
     */
    public function register()
    {
        return View::render('form.register-basic');
    }

}