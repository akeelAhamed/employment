<?php

use App\Helpers\Route;

/**
 * Welcome page
 */
Route::get('/', 'HomeController@index');

/**
 * Register page
 */
Route::get('/register', 'HomeController@register');

/**
 * API POST V1 Authenticated Route
 */
Route::post('/api/v1/json', 'Ajax\PostController@index', '', true);