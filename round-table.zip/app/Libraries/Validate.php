<?php
namespace App\Libraries;

use App\Libraries\Classes\Validator;

/**
 * Validate for app
 */
class Validate{

    /**
	 * Validate user data
	 * 
	 * @param array  $inputs User data
	 * @param string $flag Used to change rules based on flag
	 * 
	 * @return Object | response
	 */
	public static function validate(array $inputs, $flag)
	{
        $error = ['something went wrong'];
        $ok = true;
		$validate = new Validator($inputs);
        $flag = strtolower($flag);
        $ret = array('status' => false, 'message' => $error);

		switch ($flag) {
            case 'vu': // Validate user for login
				$validate->rule('required', ['userid', 'password']);
                break;
                
			case 'ca': // create account
				$validate->rule('required', ['name', 'description']);
				$validate->rule('alphaNum', ['name', 'description']);
				$validate->rule('lengthBetween', ['description'] , 10, 500)->message('Description must between 10 to 500 characters');
				break;

			case 'cau': // update account
				$validate->rule('required', ['name', 'description']);
				$validate->rule('alphaNum', ['name', 'description']);
				$validate->rule('required', 'me')->message('Something went wrong');
				$validate->rule('numeric', 'me')->message('Invalid data sent');
				$validate->rule('lengthBetween', ['description'] , 10, 500)->message('Description must between 10 to 500 characters');
				break;
			
			case 'cd': // create donars / Users
				$validate->rule('required', ['name', 'dob', 'account', 'donation', 'contact', 'enrolment_date']);
				$validate->rule('required', 'enrolment_date_g')->message('Some data\'s are missing');
				$validate->rule('alphaNum', 'name');
				$validate->rule('email', 'email');
				$validate->rule('min', 'donation', 1);
				$validate->rule('lengthBetween', 'contact' , 10, 15);
				$validate->rule('numeric', ['contact', 'donation']);
				$validate->rule('date', 'dob');
				break;

			case 'ud': // update my profile
				$validate->rule('required', ['name', 'dob', 'account', 'donation', 'contact']);
				$validate->rule('alphaNum', 'name');
				$validate->rule('email', 'email');
				$validate->rule('min', 'donation', 1);
				$validate->rule('lengthBetween', 'contact' , 10, 15);
				$validate->rule('numeric', ['contact', 'donation']);
				$validate->rule('date', 'dob');
				break;

			case 'uo': // update users/ donar details
				$validate->rule('required', ['name', 'dob', 'type', 'account', 'donation', 'contact']);
				$validate->rule('required', 'me')->message('Something went wrong');
				$validate->rule('numeric', 'me')->message('Invalid data sent');
				$validate->rule('in', 'type', \App\Models\User::TYPES);
				$validate->rule('alphaNum', 'name');
				$validate->rule('email', 'email');
				$validate->rule('lengthBetween', 'contact' , 10, 15);
				$validate->rule('numeric', ['contact', 'donation']);
				$validate->rule('date', 'dob');
				break;

			case 'ed': // create donation entry
				$validate->rule('required', ['user', 'account', 'amount', 'entry_date', 'entry_date_g']);
				$validate->rule('alphaNum', 'remarks', 10, 200)->message('Narration must between 10 to 200 characters');
				$validate->rule('array', ['entry_date', 'entry_date_g']);
				$validate->rule('required', 'entry_date.*')->message('Entry date is missing.');
				$validate->rule('required', 'entry_date_g.*')->message('Entry date is missing.');
				$validate->rule('numeric', ['user', 'account']);
				break;

			case 'od': // create other entry
				$validate->rule('required', ['ledger', 'sub_ledger', 'account', 'entry_date', 'amount']);
				$validate->rule('lengthBetween', 'remarks' , 10, 200)->message('Narration must between 10 to 200 characters');
				$validate->rule('numeric', ['amount', 'account']);
				$validate->rule('in', 'ledger', \App\Models\Ledger::TYPES);
				$validate->rule('required', 'entry_date_g')->message('Some fields are invalid');
				$validate->rule('date', 'entry_date_g')->message('Some fields are invalid');
				break;

			case 'uod': // update entry
				$validate->rule('required', ['ledger', 'sub_ledger','account', 'status', 'entry_date', 'amount']);
				$validate->rule('lengthBetween', 'remarks' , 10, 200)->message('Narration must between 10 to 200 characters');
				$validate->rule('required', 'me')->message('Something went wrong');
				$validate->rule('numeric', 'me')->message('Invalid data sent');
				$validate->rule('numeric', ['amount', 'account', 'status']);
				$validate->rule('in', 'ledger', \App\Models\Ledger::TYPES);
				$validate->rule('required', 'entry_date_g')->message('Some fields are invalid');
				$validate->rule('date', 'entry_date_g')->message('Some fields are invalid');
				break;

			case 'led': // create sub ledger entry
				$validate->rule('required', ['ledger', 'sub_ledger']);
				$validate->rule('alphaNum', 'sub_ledger');
				$validate->rule('lengthBetween', 'description', 10, 200)->message('Description must between 10 to 200 characters');
				$validate->rule('in', 'ledger', \App\Models\Ledger::TYPES);
				break;

			case 'ledu': // update sub ledger entry
				$validate->rule('required', ['ledger', 'sub_ledger']);
				$validate->rule('alphaNum', 'sub_ledger');
				$validate->rule('required', 'me')->message('Something went wrong');
				$validate->rule('numeric', 'me')->message('Invalid data sent');
				$validate->rule('lengthBetween', 'description', 10, 200)->message('Description must between 10 to 200 characters');
				$validate->rule('in', 'ledger', \App\Models\Ledger::TYPES);
				break;

			case 'd': // Delete records
				$validate->rule('required', ['api', 'key']);
				$validate->rule('array', ['key']);
				$validate->rule('equals', 'confirm_password', 'new_password');
				break;

			case 'fx': // Filter from ajax
				$validate->rule('required', ['f', 'k']);
				break;

			case 'rp': // Reset Password
				$validate->rule('required', ['old_password', 'new_password', 'confirm_password']);
				$validate->rule('lengthBetween', ['new_password', 'confirm_password'], 8, 20)->message('Minimum 8 characters required for password');
				$validate->rule('equals', 'confirm_password', 'new_password');
				break;

			case 'srp': // Send email to reset password
				$validate->rule('required', ['email']);
				$validate->rule('email', 'email');
				break;

			case 'vot': // Validate otp
				$validate->rule('required', ['code', 'key']);
				$validate->rule('required', 'id')->message('Something went wrong. Try again later');
				$validate->rule('numeric', 'code');
				break;

			case 'rpw': // Reset Password from web
				$validate->rule('required', ['new_password', 'confirm_password']);
				$validate->rule('required', ['key'])->message('Something went wrong. Try again later');
				$validate->rule('lengthBetween', ['new_password', 'confirm_password'], 8, 20)->message('Minimum 8 characters required for password');
				$validate->rule('equals', 'confirm_password', 'new_password');
				break;
                
            default:
                $ok = !$ok;
                break;
			
		}
        
        if($ok){
            if(!$validate->validate()) {
                $errors = $validate->errors();
                $error = [];
                $old_error = '';
                foreach ($errors as $key => $e) {
                    for ($i=0; $i < count($e) ; $i++) {
                        if($e[$i] != $old_error){
                            $old_error = $e[$i];
                            $key = str_replace('_', ' ', $e[$i]);
                            array_push($error, $key);
                        }
                    }
                }
                $ret = array('status' => false, 'message' => $error);
            }else{
                $ret = array('status' => true, 'message' => []);
            }
        }
        
        return json_decode(json_encode($ret));
	}
}