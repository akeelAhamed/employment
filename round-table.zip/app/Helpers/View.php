<?php 

namespace App\Helpers;

class View
{
    /**
     * Views directory path
     *
     * @var string
     */
    private static $path = ROOT_DIR.'/views';

    /**
     * Render a view
     *
     * @param string $view
     * @param array $parameters
     * @param bool  $return
     * 
     * @return mixed
     */
    public static function render($view, $parameters = array(), $return=false)
    {
        $view = \str_replace('.', '/', $view).'.php';

        return self::getContents(self::$path . '/' . $view, $parameters, $return);
    }

    /**
     * Get contents of the view
     *
     * @param string $file
     * @param array $parameters
     * @param bool  $return
     * 
     * @return mixed
     */
    public static function getContents($file, $parameters = array(), $return) 
    {
        extract($parameters, EXTR_SKIP);
        unset($parameters);

        ob_start();
        require $file;
        unset($file);
        
        $html = ob_get_clean();
        if($return){
            return $html;
        }
        echo($html);
    }
}