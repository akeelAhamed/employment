<?php

use App\Libraries\Utill;

/**
 * Gets BASE URL
 *
 * @return string
 */
function baseUrl()
{
    $currentPath = $_SERVER['PHP_SELF'];
    $pathInfo = pathinfo($currentPath);
    $hostName = $_SERVER['HTTP_HOST'];
    $protocol = strtolower(substr($_SERVER["SERVER_PROTOCOL"],0,5))=='https://'?'https://':'http://';
    
    return $protocol.$hostName.'/singapore_project/';
}

/**
 * Generate a url for application
 * 
 * @param null $url Path
 */
function url($url=null, $return=false)
{
	$url = ($url != null)?$url:'';
	$url = ROOT_URL.$url;
	if($return){
		return $url;
	}
	echo $url;
}

/**
 * Generate an asset path for application 
 * 
 * @param string $url    Path
 * @param bool   $return Is to return or echo
 */
function asset($path, $return=false)
{
	if (filter_var($path, FILTER_VALIDATE_URL) === FALSE) {
		$file = str_replace('/', DS, $path);
		$file = ROOT_DIR.'assets'.DS .$file;
		if(is_file($file)){
			$path = ROOT_URL.'assets/'.$path;
		}else{
			$path = '';
		}
	}

	if($return){
		return $path;
	}
	echo $path;
}

/**
 * Generate a url for application
 * 
 * @param string $to     Path
 * @param array  $message Redirect with message
 * @param bool   $danger  Error | Message
 * 
 * @return redirect
 */
function redirect($to='', $message=[], $success=false)
{
	$to = ($to == '')?'./':$to;
	$to = url($to, true);
	(count($message) > 0)?Utill::alert($message, $success):'';
	echo ('<script type="text/javascript">window.location.href = "'.$to.'";</script>');
}

/**
 * Similar to laravel DD Die function
 */
function dd($agrs=null)
{
	if($agrs !== null){
		echo '<pre>';
		if(!is_null($agrs)){
			echo var_dump($agrs);
		}
		echo '</pre>';
	}
	die();
}

/**
 * Include a view from view 
 * 
 * @param string $view
 * @param array $parameters
 * 
 * @return mixed
 */
function include_view($view, $parameters = array())
{
	return \App\Helpers\View::render($view, $parameters);
}

/**
 * Encrytion function
 * 
 * @param bool $echo Echo
 */
function en($data, $echo=true)
{
	$e = Utill::en($data);
	if($echo){
		echo $e;
	}
	return $e;
}

/**
 * Decrytion function
 * 
 * @param bool $echo Echo
 */
function de($data, $echo=true)
{
	$e = Utill::de($data);
	if($echo){
		echo $e;
	}
	return $e;
}

/**
 * CSRF token generator
 */
function getCsrf($e=false)
{
	$csrf = Utill::getCsrf();
	if($e){
		echo $csrf;
		return;
	}
	return $csrf;
}

/**
 * Return form CSRF field
 * 
 * @param string $api Type of request
 * 
 * @return CSRF AND API Feeld
 */
function formCsrf($api)
{
	echo '<input type="hidden" name="api" value="'.$api.'" readonly/><input type="hidden" name="'.CSRF_KEY.'" value="'.getCsrf().'" readonly/>';
}