<?php

define('DS', DIRECTORY_SEPARATOR); // Directory separotor

define('ROOT_DIR' , getcwd().DS); // root directory

/**
 * Include some more spice
 */
require ROOT_DIR.'app/Config/config.fun.php';

require ROOT_DIR.'app/Config/config.var.php';