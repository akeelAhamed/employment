<!DOCTYPE html>
<html lang="en">

<head>
  <?php include_view('include.head', ['index' => '', 'style' => ['css/form.css']]); ?>

  <style>
    #app {
      background-image: url(https://www.360karma.com/wp-content/uploads/2017/05/52676-digital_art-simple_background.png);
    }
  </style>
</head>

<body>

  <div id="app">

    <div class="main__container">

      <div class="container__child main__thumbnail">
        <div class="thumbnail__content text-center">
          <a href="javascript:void(0)" class="uk-navbar-item uk-logo logo"><img src="<?php asset('./images/logo/logo-x100.png'); ?>" alt="Logo" /></a>
          <h1 class="heading--primary">Welcome back!</h1>
          <h2 class="heading--secondary">Login to explore <?php echo APP_NAME; ?>.</h2>
        </div>
        <div class="thumbnail__links">
          <ul class="list-inline text-center">
            <li class="d-inline p-2"><a href="#" target="_blank"><i class="fa fa-globe"></i></a></li>
            <li class="d-inline p-2"><a href="#" target="_blank">
                <fa class="fa fa-behance"></fa>
              </a></li>
            <li class="d-inline p-2"><a href="#" target="_blank"><i class="fa fa-github"></i></a></li>
            <li class="d-inline p-2"><a href="#" target="_blank"><i class="fa fa-twitter"></i></a></li>
          </ul>
        </div>
        <div class="main__overlay"></div>
      </div>

      <div class="container__child main__form">
        <form action="#">
          <div class="form-group">
            <label for="username">Username</label>
            <input class="form-control" type="text" name="username" id="username" placeholder="james.bond" required />
          </div>

          <div class="form-group">
            <label for="password">Password</label>
            <input class="form-control" type="password" name="password" id="password" placeholder="********" required />
          </div>

          <div class="m-t-lg">
            <ul class="d-block">
              <li class="d-inline">
                <input class="btn btn--form" type="submit" value="Login" />
              </li>
              <li class="d-inline">
                <a class="main__link" href="<?php url('./register') ?>">Register</a>
              </li>
            </ul>
          </div>
        </form>
      </div>
    </div>
  </div>

  <?php include_view('include.script'); ?>