        <?php /* Common script to all page. Must include head.php at the top */       ?>

        <script type="text/javascript" src="<?php asset('js/0e537d0987cea355e9484c0f496ebf75f8ba7e9f40e67cfa14c9c9b3587e29c3.js');?>"></script>
        <script type="text/javascript" src="<?php asset('js/jquery-3.3.1.min.js');?>"></script>
        <script type="text/javascript" src="<?php asset('vendor/bootstrap-md/js/bootstrap.min.js');?>"></script>
        <script type="text/javascript" src="<?php asset('vendor/bootstrap-md/js/mdb.min.js');?>"></script>

        <?php
            if(isset($script)):
                foreach ($script AS $src): 
        ?>
            <script type="text/javascript" src="<?php asset($src);?>"></script>
        <?php
                endforeach;
            endif;
        ?>

        <script>
            const REQUEST = '<?php url('api/v1/json'); ?>';
            const APP = {
                letNumber : (() => {
                    $('.number').each(function (e) {
                        $(this).on('keyup', function (e) {
                            let val = $(this).val();if(isNaN(val)){
                                val = val.replace(/[^0-9\.]/g,'');
                                if(val.split('.').length>2){
                                    val =val.replace(/\.+$/,"");
                                }
                            }
                            this.value = val;
                        })
                    })
                }),

                alert : ((msg='Unable to handle the process', type=false) => {
                    let pos = "top-center";
                    type = (type)?'primary':'danger'
                    if(window.innerWidth <= 480){
                        pos = "bottom-center";
                    }
                    UIkit.notification({message: msg,status: type,pos: pos,timeout: 5000});
                }),

                toConvert: ((datepicker, ele)=>{
                    if(ele.is){
                        datepicker.changeDateMode();
                        $(ele.to).val(datepicker.getDate().getDateString());
                        datepicker.changeDateMode();
                    }
                    return;
                }),

                datePicker: ((ele = '.datepicker', ap = true) => {
                    $(ele).each(function(){
                        let picker = $(this);
                        let datepicker = new Calendar({
                                isHijriMode: true,
                                isAutoSelectedDate: true
                            });
                        let convert = {
                            is: !($(this).attr('data-to') == undefined),
                            to: $(this).attr('data-to')
                        }

                        $(this).parent().append(datepicker.getElement());

                        if(ap){
                            picker.val(datepicker.getDate().getDateString());
                            APP.toConvert(datepicker, convert);
                        };
                        picker.on('focus', function(){
                            datepicker.show();
                        });

                        datepicker.callback = function() {
                            picker.val(datepicker.getDate().getDateString());
                            picker.selectionStart = 0;
                            picker.selectionEnd = picker.val().length;
                        };

                        datepicker.onHide = function() {
                            APP.toConvert(datepicker, convert);
                        };
                    })
                }),

                navActive: ((a=null)=>{
                    $('.uk-nav a').each(function(e){
                        e = $(this);
                        a = (e.attr('href') == (location.href));
                        if($(this).hasClass('lactive')){
                            e.removeClass("lactive")
                        }else{
                            (a)?e.addClass('lactive'):'';
                        }
                    })
                }),

                submit: ((ele)=>{
                    ele = ele.find('[type=submit]');
                    ele.attr('disabled', 'disabled').attr('data-pre', ele.text()).addClass('nrs_').html('<div role="status"><div uk-spinner></div><span class="uk-margin-left">validating...</span></div>');
                }),

                resetSubmit: (()=>{
                    $('.nrs_').each(function(){
                        $(this).removeAttr('disabled').removeClass('nrs_').html($(this).data('pre'));
                    })
                }),

                api: ((param, callback, method='POST')=>{
                    param = {
                        request: param,
                        method : method,
                        time: Date.now(),
                        <?php echo CSRF_KEY; ?>: document.querySelector('meta[name=csrf]').getAttribute('content')
                    };

                    $.ajax({
                        url:REQUEST,
                        method:method,
                        data: param,
                        crossDomain: false,
                        dataType:'JSON',
                        success: ((response, status, code)=>{
                            callback(response)
                        }),
                        error: ((response, status, code)=>{
                            console.warn(response, status, code);
                        })
                    })
                }),

            };
            APP.navActive();
        </script>
    </body>
</html>