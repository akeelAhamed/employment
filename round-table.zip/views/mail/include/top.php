<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email from <?php echo APP_NAME ?></title>
</head>

<body style="background-color: #f4f4f4;">

    <div style="align-items:center;">

        <table class="container600" cellpadding="0" cellspacing="0" style="border:none;width:calc(100%);max-width:calc(600px);margin: 0 auto;min-height:100vh;" width="100%">
            <tr>
                <td width="100%" style="text-align: left;">
                    <table width="100%" cellpadding="0" cellspacing="0" style="border:none;min-width:100%;border-bottom: 1px solid #CFCFCF;">
                        <tr>
                            <td width="100%" style="min-width:100%;background-color:#ffffff;color: #494f54;padding:30px;">
                                <div style="width:70%;float:left">
                                    <img src="<?php asset('images/logo-72x72.png'); ?>" alt="<?php echo APP_NAME ?>" width="72" style="float:left;margin-top:-5px"/>
                                    <h5 style="margin-left: 5rem;"><?php echo APP_NAME ?></h5>
                                </div>
                                <div style="width:30%;float:left">
                                <h5 style="float:right;"><?php echo date('Y-m-d h:i:s A'); ?></h5>
                            </div>
                            </td>
                        </tr>

                        <tr>
                            <td width="100%" style="min-width:100%;background-color:#F8F8F8;color: #494f54;padding:0px;text-align:center">
                                <h3 style="line-height: 1px;">Assalam alikum</h3>
                            </td>
                        </tr>

                    </table>

                    <!-- CONTENT -->