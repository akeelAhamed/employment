                    <!-- END OF CONTENT -->

                    <table width="100%" cellpadding="0" cellspacing="0" style="border:none;min-width:100%;">
                        <tr>
                            <td width="100%" style="min-width:100%;background-color:#ffffff;padding:10px 20px;">
                                <p style="font-family:Georgia, Arial, sans-serif;font-size:16px;line-height:20px;border-bottom:1px solid #CCC;color:#AAA ">Note:</p>
                                <ul>
                                    <li>Don't share this emai.</li>
                                    <li>Email's with OTP or Links to your account will be expired in 30 Mins.</li>
                                    <li>It is auto generated email.</li>
                                    <li>Don't replay to this emai.</li>
                                </ul>
                            </td>
                        </tr>
                    </table>

                    <table width="100%" cellpadding="0" cellspacing="0" style="border:none;min-width:100%;">
                        <tr>
                            <td width="100%" style="min-width:100%;">
                                <table cellpadding="0" cellspacing="0" style="border:none;width:100%">
                                    <tr>
                                        <td style="padding:30px;background-color:#1e87f0;color:#ffffff;">
                                            <p style="font-family:Georgia, Arial, sans-serif;font-size:16px;line-height:20px;text-align: center;text-transform:uppercase"><?php echo date('Y'); ?> @ copyrights - <?php echo APP_NAME; ?></p>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>

    </div>
</body>

</html>