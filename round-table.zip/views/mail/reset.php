<?php include_view('mail.include.top'); ?>
    <!-- CONTENT -->

    <table width="100%" cellpadding="0" cellspacing="0" style="border:none;min-width:100%;">
        <tr>
            <td style="background-color:#F8F7F0;padding:20px;">
                <table width="100%" cellpadding="0" cellspacing="0" style="border:none;">
                    <tr>
                        <td width="100%" valign="top" style="min-width: 100%;">

                            <table class="ol col49 reorder" align="left" style="width:100%;border:none;width: calc(100%);margin:auto" cellpadding="0" cellspacing="0">
                                <tr>
                                    <td style="padding:15px 20px;">
                                        <p style="font-family: Georgia, Arial, sans-serif;font-size:16px;line-height:20px;color: #58585A;">We received a password reset request for your account registered with <?php echo APP_NAME ?>. Enter the below code to reset your password.</p>
                                    </td>
                                </tr>

                                <tr>
                                    <td valign="top" style="display:block;background-color:#ffffff;color:#000000;border:none;border:1px solid #afafaf;width:300px;margin:auto;">
                                        <h3 style="font-family:Arial;font-size:20px;line-height:24px;text-align:center"><?php echo($code); ?></h3>
                                    </td>
                                </tr>
                            </table>

                        </td>
                    </tr>
                </table>

            </td>
        </tr>
    </table>

    <!-- END OF CONTENT -->

<?php include_view('mail.include.bottom'); ?>