<?php include_view('mail.include.top'); ?>
    <!-- CONTENT -->

    <table width="100%" cellpadding="0" cellspacing="0" style="border:none;min-width:100%;">
        <tr>
            <td style="background-color:#F8F7F0;padding:20px;">
                <table width="100%" cellpadding="0" cellspacing="0" style="border:none;">
                    <tr>
                        <td width="100%" valign="top" style="min-width: 100%;">

                            <table class="ol col49 reorder" align="left" style="width:100%;border:none;width: calc(100%);margin:auto" cellpadding="0" cellspacing="0">
                                <tr>
                                    <td style="padding:15px 20px;">
                                        <p style="font-family: Georgia, Arial, sans-serif;font-size:16px;line-height:20px;color: #58585A;">Hi  <?php echo $name ?>, thanks for registered in <?php echo APP_NAME ?>. Your account was successfully created as <?php echo $utype ?>.</p>
                                    </td>
                                </tr>

                                <tr>
                                    <td valign="top" style="display:block;background-color:#ffffff;color:#000000;border:none;border:1px solid #afafaf;width:100%;margin:auto;">
                                        <h3 style="font-family:Arial;font-size:20px;line-height:24px;padding-left:20px">To login</h3>
                                        <ul style="list-style: square;color:#1e87f0;padding-left:60px">
                                            <li>Go to <a style="text-decoration:underline;color:#555555" href="<?php url();?>"><?php url();?></a></li>
                                            <li>Enter your email id and password(your contact number) to login.</li>
                                            <li>Thats all you are in.</li>
                                        </ul>
                                    </td>
                                </tr>

                                <tr>
                                    <td style="padding:0px 20px;border: 1px solid #c1c1c1;margin-top: 20px;display: block;">
                                        <p style="font-family: Georgia, Arial, sans-serif;font-size:16px;line-height:20px;color: #4CAF50;padding: 10px;">
                                            The charity of those who expend their wealth in the Way of Allah may be likened to a grain of corn, which produces seven ears and each ear yields a hundred grains. Likewise Allah develops manifold the charity of anyone He pleases, for He is All-Embracing, All-Wise.
                                            <br/><b style="width:100%;text-align:right;display: block;">Quran:- 2:261</b>
                                        </p>
                                    </td>
                                </tr>

                            </table>

                        </td>
                    </tr>
                </table>

            </td>
        </tr>
    </table>

    <!-- END OF CONTENT -->

<?php include_view('mail.include.bottom'); ?>